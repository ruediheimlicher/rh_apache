//
//  Keys.h
//  RecPlayC
//
//  Created by Ruedi Heimlicher on Sat Aug 07 2004.
//  Copyright (c) 2004 __Ruedi Heimlicher__. All rights reserved.
//

NSString*	applicationID9 	= 		@"AufnahmeCFPrefs";
NSString*	applicationIDX 	= 		@"kCFPreferencesCurrentApplication";
NSString*	applicationID;
NSString*	VersionKey= 			@"CFVersion";
NSString*	ParentIDKey= 			@"CFParentID";

NSString*	RPVolRefNumKey			=   @"RPVolRefNumID";
//NSString*	RPAufnahmenDirIDKey		=	@"RPAufnahmenDirID";
NSString*	RPAufnahmenNameKey		=	@"RPAufnahmenName";

NSString*	LeseboxDirIDKey	= 			@"LeseboxDirID";
NSString*	LeseboxnameKey	= 			@"Leseboxname";
NSString*   LeserordnerNameKey	=		@"Leserordner";
NSString*	DBDirIDKey	= 				@"DBDirID";
NSString*	DBNameKey	= 				@"DBName";

//NSString*	RPDevicedatenKey=				@"Devicedaten";
NSString*	minuseins				= @"-1";
NSString*	eins				= @"1";



