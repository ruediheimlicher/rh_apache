/* rAdminListe */

#import <Cocoa/Cocoa.h>

@interface rAdminListe : NSTableView
{

}
- (void)keyDown:(NSEvent*)event;

- (void)insertText:(NSString*)input;

@end
