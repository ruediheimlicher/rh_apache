/* rMovieView */

#import <Cocoa/Cocoa.h>

@interface rMovieView : NSMovieView
{
}
@end
