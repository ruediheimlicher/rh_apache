/* rArchivView */

#import <Cocoa/Cocoa.h>

@interface rArchivView : NSTableView
{
}
- (void)keyDown:(NSEvent *)theEvent;
@end
